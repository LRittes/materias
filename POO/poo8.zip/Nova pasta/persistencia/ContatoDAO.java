package persistencia;

public class ContatoDAO {
    
}
