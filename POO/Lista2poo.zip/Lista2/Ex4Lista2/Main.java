

import java.util.Scanner;

public class Main {
    private Turma tur = new Turma();
    private Scanner sca = new Scanner(System.in);

    public static void main(String[] args){
         Main sist = new Main();
         int op = 0;

         while (op != -1){
             System.out.println("Digite 1 para continuar e -1 para sair");

             op = sist.sca.nextInt();

             switch (op){
                 case 1:
                     sist.adicionarAluno();
                     sist.exibirAlunos();
                     break;
                 case -1:
                     sist.exibirEquipes();
                     break;
             }
         }
    }

    public Aluno novoAluno(){
        System.out.println("Nome: ");
        String nome = sca.nextLine();
        nome = sca.nextLine();

        System.out.println("Idade: ");
        int idade = sca.nextInt();

        double[] notas = new double[5];
        for(int i = 0; i<5; i++){
            System.out.println("Nota " + (i + 1) + " :");
            double nota = sca.nextDouble();
            notas[i] = nota;
        }

        Aluno alu = new Aluno();
        alu.setNome(nome);
        alu.setIdade(idade);
        alu.setNotas(notas);

        return alu;

    }

    public void adicionarAluno(){
        System.out.println("Novo aluno- ");
        Aluno aluno = novoAluno();
        tur.adicionarAluno(aluno);
    }

    public void exibirAlunos(){
        for(Aluno a: tur.retornarAlunos()){
            System.out.println( a.toString());
        }
    }

    public void exibirEquipes(){
        for(Equipe<Aluno> e: tur.separarEmEquipes()){
            System.out.println(e.getNome());
            for(Object a: e.getEquipe()){
                System.out.println(a.toString());
            }
        }
    }
}
