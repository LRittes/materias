package dados;

public class PilhaVaziaException extends Exception {
    PilhaVaziaException() {
        super("Pilha vazia");
    }
}
