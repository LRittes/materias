package dados;

public class Gato extends Animal{
    
    public String emitirSom(){
        return "MIAU";
    }

}
