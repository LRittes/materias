#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "arq_interface.h"

int sizeStrCustom(char str[]);

int sizeStr(char str[]);

void getWord(int *init, int *end, char txt[], char tmp[], ABB *a);

int howManySpaceIn(char str[]);

int calculateIntStr(char str[]);