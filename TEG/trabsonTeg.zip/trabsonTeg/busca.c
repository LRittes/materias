/*
Função:
DFS(G,v, M, marca)
    marca[v]=1
    print(v)
    para cada w adjacente a v
        se marca[w]=0
            DFS(G,n,M,marca)
        senão
            retorna
    retorna
*/

#include <stdio.h>
#include "busca.h"

void dfs(int raiz, int matAdj[][150], int vetMarca[])
{
    vetMarca[raiz] = 1;
    printf("%i ", raiz);

    for (int c = raiz + 1; c < 150; c++)
    {
        if (matAdj[raiz][c] == 1)
        {
            if (vetMarca[c] == 0)
            {
                dfs(c, matAdj, vetMarca);
            }
            else
                return;
        }
    }
    return;
}
