package dados;

public class Pessoa implements Comparable<Pessoa>{

    private String name;
    private int age;
    private int cpf;
    private String cid;

    public Pessoa(){}

    public String getNome() {
        return name;
    }

    public void setNome(String name) {
        this.name = name;
    }

    public int getIdade() {
        return age;
    }

    public void setIdade(int idade) {
        this.age = idade;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String toString(){
        return name
                + ", " + age
                + ", " + cpf
                + ", " + cid;
    }

    @Override
    public int compareTo(Pessoa p){
        return this.getNome().compareTo(p.getNome());
    }
}
