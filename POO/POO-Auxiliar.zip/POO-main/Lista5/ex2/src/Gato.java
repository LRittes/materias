public class Gato implements Animal{
    public String emitirSom(){
        return "MIAU MIAU";
    }
}