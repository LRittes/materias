from abc import ABC
 
class Pessoa(ABC):
    def __init__(self, nome):
        self.nome = nome