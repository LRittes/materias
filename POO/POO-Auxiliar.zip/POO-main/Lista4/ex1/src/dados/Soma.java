package dados;

public class Soma implements IOperacaoInteira{

    public int executar(int valor1, int valor2) {
        return valor1 + valor2;
    }
    
}