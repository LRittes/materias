public class CalculadoraInteiros implements IOperacoesBasicas<Integer>{

    public Integer somar(Integer operador1, Integer operador2) {
        return operador1 + operador2;
    }

    public Integer subtrair(Integer operador1, Integer operador2) {
        return operador1 - operador2;
    }

}