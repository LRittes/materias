

import java.util.Arrays;			

public class Aluno implements Comparable<Aluno>{
    private String name;
    private int age;
    private double[] not = new double[5];

    public Aluno(){}

    public String getNome() {
        return name;
    }

    public void setNome(String name) {
        this.name = name;
    }

    public int getIdade() {
        return age;
    }

    public void setIdade(int age) {
        this.age = age;
    }

    public double[] getNotas() {
        return not;
    }

    public void setNotas(double[] notas) {
        this.not = notas;
    }

    @Override
    public String toString() {
        return "Nome: " + name  +
                ", Idade: " + age +
                ", Notas: " + Arrays.toString(not) +
                ", Media: " + calcularMedia();
    }

    @Override
    public  int compareTo(Aluno outroAluno){
        if (this.calcularMedia() > outroAluno.calcularMedia()) {
            return -1;
        } if (this.calcularMedia() < outroAluno.calcularMedia()) {
            return 1;
        }
        return 0;
    }

    public double calcularMedia(){
        double n= 0.0;

        for(int i = 0; i < 5; i++){
            n += not[i];
        }

        return (n/ 5.0);
    }
}
