from Aviao import Aviao
from Barco import Barco

aviao1 = Aviao("bong",210000, 7)
barco1 = Barco("BMW",180000, 5)
aviao2 = Aviao("Embraer",410000, 9)
barco2 = Barco("Audi",220000, 8)
aviao1.__str__()