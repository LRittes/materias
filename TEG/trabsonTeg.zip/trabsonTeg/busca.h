#ifndef BUSCA_H_INCLUDED
#define BUSCA_H_INCLUDED

void dfs(int raiz, int matAdj[][150], int vetMarca[]);

#endif