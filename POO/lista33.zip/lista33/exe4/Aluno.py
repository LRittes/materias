from exe4.Pessoa import Pessoa


class Aluno(Pessoa,"asdas"):    
    def __init__(self, notas):
        self.notas = notas

    def calcularMedia():    
        media = 0
        for nota in self.notas:
            media += nota
        return media / self.notas.length
