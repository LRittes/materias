package dados;

public interface IOperacaoInteira {

    public int executar(int valor1, int valor2);

}