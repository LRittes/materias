package negocio;

import dados.Pessoa;

import java.util.*;


public class Sistema {
    private  Map<Integer, List<Pessoa>> faxa = new HashMap<Integer, List<Pessoa>>();

    public Sistema(){
        List<Pessoa> list;

        for(int i = 1; i <= 5; i++){
            list = new LinkedList<Pessoa>();
            faxa.put(i, list);
        }
    }

    public void adicionarPessoa(Pessoa p){
       if(p.getIdade() >= 1 && p.getIdade() <= 12){
            List<Pessoa> people = faxa.get(1);
            people.add(p);
            ordena(1);
       }

       if(p.getIdade() >= 13 && p.getIdade() <= 18){
           List<Pessoa> people = faxa.get(2);
           people.add(p);
           ordena(2);
       }

        if(p.getIdade() >= 19 && p.getIdade() <= 25){
            List<Pessoa> people = faxa.get(3);
            people.add(p);
            ordena(3);
        }

        if(p.getIdade() >= 26 && p.getIdade() <= 59){
            List<Pessoa> people = faxa.get(4);
            people.add(p);
            ordena(4);
        }

        if(p.getIdade() >= 60){
            List<Pessoa> people = faxa.get(5);
            people.add(p);
            ordena(5);
        }
    }

    public void ordena(int n){
        List<Pessoa> lista = faxa.get(n);
        Collections.sort(lista);
    }

    public Map<Integer, List<Pessoa>> retPessoas(){
        return faxa;
    }
}
