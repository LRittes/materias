public interface IOperacoesBasicas<T>{
    
    public T somar(T operador1, T operador2);

    public T subtrair(T operador1, T operador2);

}