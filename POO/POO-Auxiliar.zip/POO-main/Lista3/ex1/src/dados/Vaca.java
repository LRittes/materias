package dados;

public class Vaca extends Animal{
    
    public String emitirSom(){
        return "MUUU";
    }

}
