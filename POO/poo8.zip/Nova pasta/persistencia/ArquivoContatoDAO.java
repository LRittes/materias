package persistencia;

public class ArquivoContatoDAO {
    
}
