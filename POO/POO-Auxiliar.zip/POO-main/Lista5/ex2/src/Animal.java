public interface Animal{
    public String emitirSom();
}