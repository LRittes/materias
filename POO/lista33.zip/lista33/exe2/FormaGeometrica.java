package exe2;

public abstract class FormaGeometrica {
    protected int medida1;
    protected int medida2;

    public abstract double calcularArea();

    public abstract double calcularPerimetro();
}
