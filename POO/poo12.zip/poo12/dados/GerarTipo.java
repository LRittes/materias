package dados;

public enum GerarTipo {
    FIBONACCI, NATURAL, FATORIAL;
}