public class Cao implements Animal{
    public String emitirSom(){
        return "AU AU";
    }
}