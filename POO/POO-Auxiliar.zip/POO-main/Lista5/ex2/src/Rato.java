public class Rato implements Animal{
    public String emitirSom(){
        return "CHII CHII";
    }
}