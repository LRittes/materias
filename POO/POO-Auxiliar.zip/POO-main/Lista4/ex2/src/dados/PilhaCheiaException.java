package dados;

public class PilhaCheiaException extends Exception{
    PilhaCheiaException(){
        super("Pilha cheia");
    }
}
