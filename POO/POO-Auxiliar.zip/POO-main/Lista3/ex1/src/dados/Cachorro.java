package dados;

public class Cachorro extends Animal{
    
    public String emitirSom(){
        return "AU AU";
    }

}
