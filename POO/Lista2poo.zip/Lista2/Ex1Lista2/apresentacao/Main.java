package apresentacao;

import negocio.Sistema;
import dados.Pessoa;

import java.util.Scanner;

public class Main {
    private Sistema li = new Sistema();
    private Scanner sca = new Scanner(System.in);

    public static void main(String[] args){
        Main lista = new Main();
        int op = 0;

        while (op != -1){
            System.out.println("Digite 1 para continuar e -1 para encerrar");
            System.out.println("--> ");

            op = lista.sca.nextInt();

            switch (op){
                case 1:
                    lista.adicionarPessoa();
                    lista.exibirPessoas();
                    break;
                case -1:
                    break;
            }
        }
    }

    public Pessoa novaPessoa(){
        System.out.println("Nome: ");
        String name = sca.nextLine();
        name = sca.nextLine();

        System.out.println("Idade: ");
        int idade = sca.nextInt();

        System.out.println("CPF: ");
        int cpf = sca.nextInt();

        System.out.println("Cidade: ");
        String cidade = sca.nextLine();
        cidade = sca.nextLine();

        Pessoa p = new Pessoa();
        p.setNome(name);
        p.setIdade(idade);
        p.setCpf(cpf);
        p.setCid(cidade);

        return p;
    }

    public void adicionarPessoa(){
        System.out.println("Novo Contato");
        Pessoa pessoa = novaPessoa();
        li.adicionarPessoa(pessoa);
    }

    public void exibirPessoas(){
        li.retPessoas().forEach(
                (ch, li) -> {
                    switch (ch){
                        case 1:
                            System.out.println("1 até 12: crianças;");
                            break;
                        case 2:
                            System.out.println("\n13 at ́e 18: adolescentes;");
                            break;
                        case 3:
                            System.out.println("\n19 at ́e 25: jovens;");
                            break;
                        case 4:
                            System.out.println("\n26 at ́e 59: adultos;");
                            break;
                        case 5:
                            System.out.println("\n60 ou mais: idosos;");
                            break;
                    }
                    System.out.println("\n");
                    li.forEach(pessoa ->{
                        System.out.println(pessoa.toString());
                    });
                }
        );
    }
}
