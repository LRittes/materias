

import java.util.Collections;

import java.util.ArrayList;
import java.util.List;

public class Turma{
    private List<Aluno> alun = new ArrayList<Aluno>();

    public Turma(){}

    public void adicionarAluno(Aluno alu){
        alun.add(alu);
    }

    private void ordenarPorMedia(){
        Collections.sort(alun);
    }

    public List<Equipe<Aluno>> separarEmEquipes(){
        ordenarPorMedia();
        int qua = alun.size();
        int div4, div3, posi = 0, c = 1;

        List<Equipe<Aluno>> equipes = new ArrayList<Equipe<Aluno>>();
        Equipe<Aluno> eq;

        // Número de elementos por grupo
        if(qua % 4 == 0){
            div4 = qua / 4;
            for(int i=0; i<div4; i++){
                eq = new Equipe<Aluno>();
                eq.setNome("Equipe " + c);

               eq.getEquipe().add(alun.get(posi));
               posi++;
               eq.getEquipe().add(alun.get(posi));
               posi++;

               qua--;
               eq.getEquipe().add(alun.get(qua));
               qua--;
               eq.getEquipe().add(alun.get(qua));
               qua--;

               c++;
               equipes.add(eq);
            }
        }else{
            div4  = qua / 4;
            div3 = (qua % 4) / 3;

            for(int i=0; i<div4; i++){
                eq = new Equipe<Aluno>();
                eq.setNome("Equipe " + c);

                eq.getEquipe().add(alun.get(posi));
                posi++;
                eq.getEquipe().add(alun.get(posi));
                posi++;

                qua--;
                eq.getEquipe().add(alun.get(qua));
                qua--;
                eq.getEquipe().add(alun.get(qua));
                qua--;

                c++;
                equipes.add(eq);
            }

            for(int i=0; i<div3; i++){
                eq = new Equipe<Aluno>();
                eq.setNome("Equipe " + c);

                eq.getEquipe().add(alun.get(posi));
                posi++;
                eq.getEquipe().add(alun.get(posi));
                posi++;

                qua--;
                eq.getEquipe().add(alun.get(qua));
                qua--;

                c++;
                equipes.add(eq);
            }

        }

        return equipes;
    }

    public List<Aluno> retornarAlunos(){
        return alun;
    }
}
