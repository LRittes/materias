public class Sapo implements Animal{
    public String emitirSom(){
        return "QUAC QUAC";
    }
}