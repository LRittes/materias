

import java.util.ArrayList;
import java.util.List;

public class Equipe<T>{
    private String name;
    private List<T> eq = new ArrayList<T>();

    public Equipe(){}

    public String getNome() {
        return name;
    }

    public void setNome(String name) {
        this.name = name;
    }

    public List<T> getEquipe() {
        return eq;
    }

    public void setEquipe(List<T> eq) {
        this.eq = eq;
    }

    @Override
    public String toString() {
        return "Equipe: " +
                "\nNome: " + name +
                "\nMebros" + eq;
    }
}
