public class NomeInvalidoException extends Exception{
    NomeInvalidoException(String str){
        super(str);
    }
}
