package POO6;

public class Quadrados extends Gerador {

    @Override
    public void gerar(int qnt) {
        for (int i = 0; i < qnt; i++) {
        }
    }

}
