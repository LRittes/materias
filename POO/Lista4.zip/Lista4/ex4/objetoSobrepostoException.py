class ObjetoSobrepostoException(Exception):
    pass