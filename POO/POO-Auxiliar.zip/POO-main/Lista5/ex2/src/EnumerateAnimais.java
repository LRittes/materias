public class EnumerateAnimais {
    Cao, Gato, Sapo, Rato, Cobra;
}