public class Principal {
    private ReservaPassagem reservaPassagem;

    public void fazerReserva() {
    }

    public void cadastrarCliente() {
    }

    public void cadastrarCidade() {
    }

    public void mostrarReservas() {
    }

}
