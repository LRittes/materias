#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

float encontrarMenor(float vetDist[][3], int linhas) {
  float menor = vetDist[0][2];
  for (int i = 0; i < linhas; i++) {
    menor = fmin(menor, vetDist[i][2]);
  }
  return menor;
}

float encontrarMaior(float vetDist[][3], int linhas) {
  float maior = vetDist[0][2];
  for (int i = 0; i < linhas; i++) {
    maior = fmax(maior, vetDist[i][2]);
  }
  return maior;
}

int main() {
  FILE *arquivo;
  char linha[100];
  char *token;

  arquivo = fopen("IrisDataset.csv", "r"); // abre o arquivo em modo leitura

  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo!\n");
    exit(1);
  }

  int c = 0;
  float vets[150][4];
  while (fgets(linha, 100, arquivo)) { // lê uma linha do arquivo
    token =
        strtok(linha, ","); // separa a linha em campos separados por vírgula

    int i = 0;

    while (token != NULL) { // lê cada campo
      vets[c][i] = atof(token);
      token = strtok(NULL, ",");
      i++;
    }
    c++;
  }
  fclose(arquivo); // fecha o arquivo

  float vetDist[12000][3];
  int totalLines = 0;
  for (int j = 0; j < 150; j++) {
    for (int s = j + 1; s < 150; s++) {
      vetDist[totalLines][0] = j + 1;
      vetDist[totalLines][1] = s + 1;
      float dist = 0;
      for (int i = 0; i < 4; i++) {
        dist += pow((vets[j][i] - vets[s][i]), 2);
      }
      vetDist[totalLines][2] = sqrt(dist);

      totalLines++;
    }
  }

  float menor = encontrarMenor(vetDist, totalLines);
  float maior = encontrarMaior(vetDist, totalLines);

  float vetNorms[totalLines][3];
  for (int j = 0; j < totalLines; j++) {
    vetNorms[j][0] = vetDist[j][0];
    vetNorms[j][1] = vetDist[j][1];
    vetNorms[j][2] = (vetDist[j][2] - menor) / (maior - menor);
  }

  float vetLimiar[totalLines][3];
  int count = 0;
  for (int i = 0; i < totalLines; i++) {
    if (vetNorms[i][2] <= 0.3) {
      vetLimiar[count][0] = vetNorms[i][0];
      vetLimiar[count][1] = vetNorms[i][1];
      vetLimiar[count][2] = vetNorms[i][2];
      count++;
    }
  }

  FILE *arquivo2;
  arquivo2 = fopen("grafo.txt", "a");
  if (arquivo2 == NULL) {
    printf("Erro ao abrir o arquivo.");
    return 1;
  }
  fprintf(arquivo2, "%i\n", count);
  for (int i = 0; i < count; i++) {
    fprintf(arquivo2, "%i,%i", (int)vetLimiar[i][0], (int)vetLimiar[i][1]);
    fprintf(arquivo2, "\n");
  }
  fclose(arquivo2);

  return 0;
}