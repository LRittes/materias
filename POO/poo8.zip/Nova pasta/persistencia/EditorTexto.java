package persistencia;

import java.util.List;

public class EditorTexto {
    public List<String> leTexto(String path){

    }

    public void gravaTexto(String path, List<String> data){

    }
}
