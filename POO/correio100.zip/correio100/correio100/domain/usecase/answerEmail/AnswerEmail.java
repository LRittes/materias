package domain.usecase.answerEmail;

import domain.entity.Email;

public interface AnswerEmail {
    public void answerEmail(Email email) throws Exception;
}
